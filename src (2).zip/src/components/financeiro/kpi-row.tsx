const formatoBRL = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
  maximumFractionDigits: 0,
});
const formatoNumero = new Intl.NumberFormat('pt-BR');

export type KpiBadgeVariant = 'up' | 'down' | 'neutral';

export type KpiBadge = {
  /** Texto do badge, sem a seta (ex: "64,4%" ou "em aberto") */
  texto: string;
  variant: KpiBadgeVariant;
};

export type Kpi = {
  label: string;
  valor: number;
  /** Cor do valor principal — precisa bater com .kpi-val.green/.red/.blue no CSS */
  cor?: 'red' | 'green' | 'blue';
  /** 'moeda' (padrão, R$) ou 'numero' (para o toggle "Qtde") */
  formato?: 'moeda' | 'numero';
  badge?: KpiBadge;
  /** Texto secundário do rodapé, ex: "vs. mês anterior" ou "Mai/2026" */
  sub?: string;
};

const seta: Record<KpiBadgeVariant, string> = {
  up: '▲',
  down: '▼',
  neutral: '—',
};

function formatarValor(k: Kpi) {
  return k.formato === 'numero' ? formatoNumero.format(k.valor) : formatoBRL.format(k.valor);
}

export default function KpiRow({ kpis }: { kpis: Kpi[] }) {
  return (
    <div className="kpi-row">
      {kpis.map((k) => (
        <div key={k.label} className="kpi">
          <div className="kpi-label">{k.label}</div>
          <div className={`kpi-val ${k.cor ?? ''}`}>{formatarValor(k)}</div>

          {(k.badge || k.sub) && (
            <div className="kpi-footer">
              {k.badge && (
                <span className={`badge ${k.badge.variant}`}>
                  {seta[k.badge.variant]} {k.badge.texto}
                </span>
              )}
              {k.sub && <span className="kpi-sub">{k.sub}</span>}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}