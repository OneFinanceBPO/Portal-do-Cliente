'use client';

import { useEffect, useRef, useState } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import KpiRow from '@/components/financeiro/kpi-row';
import { CORES, gradiente, opcoesBase } from '@/components/financeiro/chart-theme';
import '@/components/financeiro/chart-setup';

const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

export default function ContasReceberClient({ clienteId }: { clienteId: string }) {
  const [ano, setAno] = useState(new Date().getFullYear());
  const [dados, setDados] = useState<any>(null);
  const [carregando, setCarregando] = useState(true);
  const barRef = useRef<any>(null);

  useEffect(() => {
    setCarregando(true);
    fetch(`/api/v1/financeiro?clienteId=${clienteId}&ano=${ano}`)
      .then((r) => r.json())
      .then(setDados)
      .finally(() => setCarregando(false));
  }, [clienteId, ano]);

  if (carregando || !dados) return <div className="page"><p>Carregando…</p></div>;

  const { kpisRec, meses, abertoRecPorMes } = dados;
  const totalDonut = kpisRec.vencidas + kpisRec.aVencer + kpisRec.recebidas;

  return (
    <div className="page">
      <div className="filter-row">
        <span className="filter-lbl">Ano</span>
        <select className="filter-sel" value={ano} onChange={(e) => setAno(Number(e.target.value))}>
          {[ano - 1, ano, ano + 1].map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
      </div>

      <KpiRow kpis={[
        { label: 'Transações Vencidas', valor: kpisRec.vencidas, cor: 'red', icone: '⚠️', sub: `no ano de ${ano}` },
        { label: 'Transações A Vencer', valor: kpisRec.aVencer, cor: 'blue', icone: '📅', sub: 'em aberto' },
        { label: 'Transações Recebidas', valor: kpisRec.recebidas, cor: 'green', icone: '✅', sub: `no ano de ${ano}` },
        { label: 'Total do Período', valor: kpisRec.total, icone: '💰' },
      ]} />

      <div className="charts-21">
        <div className="chart-card">
          <div className="chart-title">Recebidos por Mês</div>
          <div className="chart-wrap" style={{ height: '230px' }}>
            <Bar
              ref={barRef}
              data={{
                labels: MESES,
                datasets: [{
                  label: 'Recebido',
                  data: meses.map((m: any) => m.recTotal),
                  backgroundColor: (ctx: any) => {
                    const chart = ctx.chart;
                    if (!chart.ctx) return CORES.verde;
                    return gradiente(chart.ctx, CORES.verde, chart.height);
                  },
                  borderRadius: 6,
                  borderSkipped: false,
                  maxBarThickness: 32,
                }],
              }}
              options={{ ...opcoesBase, plugins: { ...opcoesBase.plugins, legend: { display: false } } }}
            />
          </div>
        </div>

        <div className="chart-card">
          <div className="chart-title">% Status a Receber</div>
          <div className="chart-wrap" style={{ height: '230px' }}>
            <Doughnut
              data={{
                labels: ['Vencidas', 'A Vencer', 'Recebidas'],
                datasets: [{
                  data: [kpisRec.vencidas, kpisRec.aVencer, kpisRec.recebidas],
                  backgroundColor: [CORES.vermelho, CORES.azul, CORES.verde],
                  borderColor: '#0d1638',
                  borderWidth: 3,
                  hoverOffset: 6,
                }],
              }}
              options={{
                ...opcoesBase,
                cutout: '72%',
                scales: undefined,
                plugins: { ...opcoesBase.plugins },
                _centroTexto: {
                  valor: new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', notation: 'compact' }).format(totalDonut),
                  label: 'Total',
                },
              } as any}
            />
          </div>
        </div>
      </div>

      <div className="charts-1">
        <div className="chart-card">
          <div className="chart-title">Em Aberto — A Vencer vs Vencidos ({ano})</div>
          <div className="chart-wrap" style={{ height: '210px' }}>
            <Bar
              data={{
                labels: MESES,
                datasets: [
                  { label: 'A Vencer', data: abertoRecPorMes.map((m: any) => m.aVencer), backgroundColor: CORES.azul, stack: 's', borderRadius: 4, maxBarThickness: 28 },
                  { label: 'Vencidos', data: abertoRecPorMes.map((m: any) => m.vencidos), backgroundColor: CORES.vermelho, stack: 's', borderRadius: 4, maxBarThickness: 28 },
                ],
              }}
              options={{
                ...opcoesBase,
                scales: {
                  x: { ...opcoesBase.scales!.x, stacked: true },
                  y: { ...opcoesBase.scales!.y, stacked: true },
                },
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}